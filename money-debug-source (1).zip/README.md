# Money Debug

Meteor Client addon for Minecraft 1.21.11 (DonutSMP).

Modules (category **Money Debug**):
- **sus-chunk-finder**: amethyst-growth heat map (default) or classic storage/kelp scan
- **staff-list**: DonutSMP staff tracker (online / spectator / vanished, nearby distance)
- **anti-vanish**: TAB hide, silent TAB removal, /msg completion probe, invisible staff

HUD: **staff-list**, **money-debug**

## Build
```
gradlew build
```
Jar ends up in `build/libs`. Needs JDK 21.

## License
GPL-3.0 (see LICENSE). Staff list, anti-vanish and amethyst sus chunk logic ported from Anubis by 4ldenz.
