/*
 * Money Debug - Meteor addon for DonutSMP.
 * Staff list, anti-vanish and sus chunk finder logic ported from Anubis by 4ldenz (GPL-3.0).
 * This addon is licensed under GPL-3.0; see LICENSE.
 */
package com.moneydebug;

import com.moneydebug.hud.DebugHud;
import com.moneydebug.hud.StaffListHud;
import com.moneydebug.modules.AntiVanish;
import com.moneydebug.modules.StaffList;
import com.moneydebug.modules.SusChunkFinder;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.systems.hud.Hud;
import meteordevelopment.meteorclient.systems.hud.HudGroup;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.item.Items;

public class MoneyDebug extends MeteorAddon {
    public static final Category CATEGORY = new Category("Money Debug", Items.EMERALD.getDefaultStack());
    public static final HudGroup HUD_GROUP = new HudGroup("Money Debug");

    @Override
    public void onInitialize() {
        Modules.get().add(new SusChunkFinder());
        Modules.get().add(new StaffList());
        Modules.get().add(new AntiVanish());
        Hud.get().register(StaffListHud.INFO);
        Hud.get().register(DebugHud.INFO);
        MeteorClient.EVENT_BUS.subscribe(this);
    }

    private boolean hudPlaced;

    /** Puts the Money Debug HUD elements on screen the first time you join a world, if they are missing. */
    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (hudPlaced || MeteorClient.mc.player == null) return;
        hudPlaced = true;
        Hud hud = Hud.get();
        hud.active = true;
        if (!has(hud, StaffListHud.INFO)) hud.add(StaffListHud.INFO, 4, 120);
        if (!has(hud, DebugHud.INFO)) hud.add(DebugHud.INFO, 4, 220);
    }

    private static boolean has(Hud hud, HudElementInfo<?> info) {
        for (HudElement e : hud) if (e.info == info) return true;
        return false;
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.moneydebug";
    }
}
